import numpy as np 
from Global_Variables import *
